﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EventsManagementPortal.Dal;
using EventsManagementPortal.Entities;
using PagedList;
namespace EventsManagementPortal.UI.Areas.WebPoCEvents.Controllers
{
    public class HomeController : Controller
    {
        private readonly ICommonRepository<Event> eventDal;
        public HomeController(ICommonRepository<Event> eventRepo)
        {
            eventDal = eventRepo;
        }
        // GET: WebPoCEvents/Home
        public ActionResult Index(int page = 1)
        {
            ViewBag.PageTitle = "Welcome To WebPoCHub Future Events List!";
            ViewBag.SubTitle = "Published by WebPoCHub Global Hr Team!";
            var events = eventDal.GetAll();
            int pageSize = 2;
            return View(events.ToPagedList(page, pageSize));
        }
        public ActionResult Details(int id)
        {
            ViewBag.PageTitle = "Details Of - ";
            var @event = eventDal.GetDetails(id);
            return View(@event);
        }
    }
}