﻿using System.Web.Mvc;

namespace EventsManagementPortal.UI.Areas.WebPoCEmployees
{
    public class WebPoCEmployeesAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "WebPoCEmployees";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "WebPoCEmployees_default",
                "WebPoCEmployees/{controller}/{action}/{id}",
                new { controller = "Home", action = "Index", id = UrlParameter.Optional },
                new string[] { "EventsManagementPortal.UI.Areas.WebPoCEmployees.Controllers" }
            );
        }
    }
}