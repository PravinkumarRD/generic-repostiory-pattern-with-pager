﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EventsManagementPortal.Dal;
using EventsManagementPortal.Entities;

namespace EventsManagementPortal.UI.Areas.WebPoCEmployees.Controllers
{
    public class HomeController : Controller
    {
        private readonly ICommonRepository<Employee> employeeDal;
        public HomeController(ICommonRepository<Employee> employeeRepo)
        {
            employeeDal = employeeRepo;
        }
        public ActionResult Index()
        {
            ViewBag.PageTitle = "Welcome To WebPoCHub Employees List!";
            ViewBag.SubTitle = "Core Employees List  Of WebPoCHub Global Teams!";
            var employees = employeeDal.GetAll();
            return View(employees);
        }
        public ActionResult Details(int id)
        {
            ViewBag.PageTitle = "Details Of - ";
            var employee = employeeDal.GetDetails(id);
            return View(employee);
        }
    }
}